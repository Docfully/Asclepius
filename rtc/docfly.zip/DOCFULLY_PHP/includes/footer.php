		<div id="footer">Copyright 2007, Widget Corp</div>
	</body>
</html>