<!DOCTYPE html>
<html>
	<head>
		<title>Widget Corp</title>
		<link rel="stylesheet" type="text/css" media="all" href="stylesheets/public.css">
	</head>
	<body>
		<div>
			<h1>Widget Corp</h1>
		</div>