<?php 
	// 5. Close connection
 	if (isset($dbhandle)) {
 		mysqli_close($dbhandle);
 	}
?>